# Installation — aaa-v1-workflow-generator

**Package revision:** 1.1.0

## Global skill-directory installation

Unzip the package so that the final folder is:

```text
/home/oai/skills/aaa-v1-workflow-generator/
  SKILL.md
  references/
  templates/
```

Example on a compatible environment:

```bash
unzip aaa-v1-workflow-generator-v1.1.0.zip -d /home/oai/skills/
```

Then confirm:

```bash
test -f /home/oai/skills/aaa-v1-workflow-generator/SKILL.md && echo "installed"
```

If your Codex/ChatGPT skill host uses a different global skills directory, unzip the same top-level folder into that directory instead. Do not flatten the package; `SKILL.md` must remain at the root of the `aaa-v1-workflow-generator` folder.

## Suggested invocation

Use natural-language requests such as:

```text
Use aaa-v1-workflow-generator to plan this study.
Use AAA v1.0 to audit this literature review.
Resume my AAA v1.0 workflow from the current artifacts.
Run AAA Step 8 on these full-text papers.
Generate the AAA v1.0 flowchart specification.
```

## Package scope

This package contains workflow instructions and templates only. It does not bundle proprietary source files or external AI tools.
