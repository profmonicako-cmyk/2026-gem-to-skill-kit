# AAA v1.0 Search Log

## Research question
- Confirmed question:
- Framework:
- Date confirmed:
- Confirmed by:

## Search concept matrix
| Concept block | Controlled vocabulary | Keywords/synonyms | Exclusions/notes |
|---|---|---|---|
| 1 |  |  |  |
| 2 |  |  |  |
| 3 |  |  |  |

## Database search records
| Search ID | Database/platform | Date | Full query | Filters/limits | Hits | Export file | Notes |
|---|---|---|---|---|---:|---|---|
| S001 |  |  |  |  |  |  |  |

## Citation mapping / snowballing
| Mapping ID | Seed paper/source | Tool/method | Date | Forward/backward | Candidate count | Notes |
|---|---|---|---|---|---:|---|
| M001 |  |  |  |  |  |  |

## Screening summary
| Stage | Records | Included | Excluded | Exclusion reasons documented? |
|---|---:|---:|---:|---|
| Deduplicated |  |  |  |  |
| Title/abstract |  |  |  |  |
| Full text |  |  |  |  |

## Full-text retrieval exceptions
| Source ID | Citation | Retrieval status | Reason unavailable | Action |
|---|---|---|---|---|
|  |  |  |  |  |
