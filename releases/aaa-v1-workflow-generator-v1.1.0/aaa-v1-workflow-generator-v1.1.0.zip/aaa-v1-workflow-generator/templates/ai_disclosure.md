# AAA v1.0 AI Use Disclosure — Author Confirmation Required

> This is a drafting template. Replace placeholders only with facts that actually occurred. Unknown details must remain marked for author confirmation.

## 1. General declaration
Generative AI tools were used in the following phases of this project: [AUTHOR TO CONFIRM].

## 2. Tools and specifications
| Tool | Provider/developer | Model/version | Date/period used | Material settings | Purpose |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## 3. Prompting
Representative prompting techniques/prompts:
- [AUTHOR TO CONFIRM]

## 4. Role of AI
AI was used for: [e.g., search-term expansion / reading assistance / candidate Atomic Sentence extraction / organization / language editing / reviewer simulation — AUTHOR TO CONFIRM].

AI was not used for: [AUTHOR TO CONFIRM].

## 5. New model development
A new generative AI model was: [not developed / developed — AUTHOR TO CONFIRM].

## 6. AI-assisted manuscript sections
Sections receiving AI assistance:
- [AUTHOR TO CONFIRM]

## 7. Verification and human oversight
All AI-assisted citation-bearing claims were handled under the AAA v1.0 source-verification workflow. Candidate evidence units were cross-referenced against the original source by a human researcher before being marked VERIFIED. Units that failed verification were discarded rather than repaired in place. [MODIFY TO MATCH ACTUAL PROCEDURE]

## 8. Privacy and data governance
Data uploaded to AI tools:
- [AUTHOR TO CONFIRM]

Identifiable/sensitive data handling:
- [AUTHOR TO CONFIRM]

## 9. Impact on conclusions
The final interpretation and conclusions were determined and approved by the human authors. The role of AI in shaping conclusions was: [AUTHOR TO CONFIRM].

## Final author checklist
- [ ] Tool names/versions are accurate.
- [ ] No unperformed verification procedure is claimed.
- [ ] Privacy statements match actual data handling.
- [ ] AI-assisted sections are fully disclosed.
- [ ] Human responsibility for final content is explicit.
