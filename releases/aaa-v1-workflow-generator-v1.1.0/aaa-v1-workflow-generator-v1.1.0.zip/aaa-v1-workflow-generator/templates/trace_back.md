# AAA v1.0 Draft Trace-Back Record

## Document
- Title:
- Version/date:
- Auditor:

## Claim-level trace-back

### Claim C001
- Manuscript section:
- Paragraph/line:
- Claim text:
- Claim type: background | method | finding | mechanism | limitation | interpretation | recommendation
- Verified AS ID:
- Source ID:
- Source locator:
- Citation as written:
- Trace-back result: PASS | PARTIAL | BLOCKED | NOT ASSESSABLE
- Notes:

## Paragraph-level integrity check
For each paragraph confirm:
- [ ] Every substantive empirical claim has verified support.
- [ ] Citation placement makes attribution unambiguous.
- [ ] No citation supports more than the source actually states.
- [ ] No transition sentence introduces a new factual claim without evidence.
- [ ] Interpretation is distinguished from reported source findings.

## Orphan checks
- Uncited references found:
- Citations not present in the verified library:
- Claims without verified evidence:
- Claims requiring Step 17 evidence loop:
