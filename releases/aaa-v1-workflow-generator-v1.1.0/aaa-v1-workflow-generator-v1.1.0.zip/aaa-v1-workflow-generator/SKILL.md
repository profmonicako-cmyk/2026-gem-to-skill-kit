---
name: aaa-v1-workflow-generator
description: Run, explain, audit, resume, and export the AAA v1.0 (AI Assisted Academic Writing) source-verified 18-step workflow. Enforces human-governed evidence states, Atomic Sentence verification, claim-level traceability, evidence-constrained drafting, reviewer-triggered evidence loops, and GAMER/ICMJE-style AI disclosure.
---

# AAA v1.0 Workflow Generator

**Package revision: 1.1.0 (2026-08-29)**

Revision 1.1.0 preserves the AAA v1.0 six-gate/18-step SOP and adds canonical execution specifications for Appendix 1 Prompt 1 (Step 8), Appendix 1 Prompt 2 (Step 14A), and the article-aligned Write-and-Polish boundary (Step 14B).

Use this skill when the user wants to plan, execute, audit, resume, teach, or export the **AAA v1.0 (AI Assisted Academic Writing) revised 18-step SOP**.

The skill is a workflow controller, not a generic academic-writing prompt. Its purpose is to keep research claims source-verified, auditable, and under explicit human control.

## Core operating principle

**No substantive claim enters the controlled manuscript unless it has passed source verification, and no new claim introduced by AI may bypass the evidence loop.**

The workflow is organized as six gates and eighteen canonical steps. Do not silently renumber, merge, reorder, or replace them. If the user explicitly asks for a modified/new version, preserve AAA v1.0 as the baseline and clearly label the derivative version.

## When to invoke

Invoke for requests such as:
- explain or teach AAA v1.0;
- plan a research project using AAA v1.0;
- identify the user’s current AAA step and continue;
- convert a research observation into a structured workflow;
- extract candidate Atomic Sentences from full text;
- create a verification table or Verified AS Library;
- draft only from verified evidence;
- audit a draft for claim-to-source traceability;
- simulate peer review without allowing unsupported claims into the draft;
- generate AI-use disclosure / GAMER-style reporting;
- export the 18-step workflow as a table, checklist, handout, or flowchart specification.

## Supported modes

Infer the mode from the request unless the user states one explicitly.

1. `explain` — explain the six gates, eighteen steps, evidence states, and guardrails.
2. `plan` — create a project-specific execution plan mapped to all 18 steps.
3. `run` — execute the requested/current step while preserving state and gate rules.
4. `audit` — inspect an existing workflow/draft for AAA compliance and traceability gaps.
5. `resume` — infer the current step from available artifacts and continue from there.
6. `export` — generate structured workflow content suitable for tables, handouts, or diagrams.

## Progressive-discovery files

Read only what is needed for the task:
- `references/aaa_v1_canonical_18steps.md` — canonical six gates and 18 steps.
- `references/evidence_states.md` — evidence-state model and transition rules.
- `references/gate_rules.md` — pass criteria and blocking conditions for each gate.
- `references/atomic_sentence_sps.md` — Atomic Sentence definition, metadata, SPS, and verification logic.
- `references/candidate_as_prompt.md` — canonical Appendix 1 Section 7 Prompt 1 for Step 8.
- `references/verified_as_synthesis_prompt.md` — canonical Appendix 1 Section 7 Prompt 2 for Step 14A.
- `references/write_and_polish_wrapper.md` — constrained Write-and-Polish rules for Step 14B.
- `references/gamer_reporting.md` — GAMER-oriented AI reporting checklist and disclosure guidance.
- `templates/project_state.yaml` — persistent project state schema.
- `templates/search_log.md` — database/citation-mapping search log.
- `templates/candidate_as.csv` — candidate Atomic Sentence working table.
- `templates/prompt1_candidate_as.txt` — parameterized executable Prompt 1.
- `templates/prompt2_verified_as_synthesis.txt` — executable Prompt 2.
- `templates/write_and_polish_wrapper.txt` — constrained polishing wrapper.
- `templates/verified_as.csv` — verified Atomic Sentence library.
- `templates/claim_evidence_matrix.csv` — claim-to-evidence audit table.
- `templates/trace_back.md` — paragraph/claim trace-back record.
- `templates/ai_disclosure.md` — AI-use disclosure drafting template.

## Non-negotiable guardrails

### 1. Never invent references
`MUST NOT invent references, DOIs, quotations, page numbers, statistics, study characteristics, or bibliographic details.`

If a source cannot be verified from available material, mark it as unverified or request/retrieve the source. Do not guess.

### 2. Evidence-state authority belongs to the human researcher
`MUST NOT upgrade AI-generated notes from UNVERIFIED or TO VERIFY to VERIFIED.`

Only explicit human cross-reference verification against the original source can authorize the state `VERIFIED`.

AI may assist by preparing a comparison table, locating passages, flagging inconsistencies, or identifying what must be checked, but it must not represent that process as completed human verification unless the user explicitly confirms it.

### 3. Validity precedes quality
`Step 10 source verification MUST occur before Step 12 SPS scoring is treated as a quality gate.`

SPS measures the quality/reusability of an Atomic Sentence; it does not prove truth or citation validity.

### 4. Verification failure means discard, not repair
If the reference does not exist or the source does not support the exact claim/statistic, the unit is `DISCARD`.

Do not “fix” a failed unit by changing the wording while retaining the old citation. A materially altered unit is a new candidate and must be re-verified.

### 5. New claims trigger the evidence loop
Any new substantive factual claim, statistic, causal statement, comparison, or citation need introduced during drafting, editing, or peer-review simulation triggers Step 17 and returns to Steps 4–12.

### 6. Nongrounded AI tools cannot introduce controlled citations
Nongrounded language models may assist with:
- ideation;
- organization;
- explanation;
- language editing;
- rhetorical refinement;
- reviewer simulation.

They may not introduce a citation into the controlled draft unless that citation subsequently passes the AAA source-verification workflow.

### 7. Human accountability is explicit
The human researcher retains responsibility for:
- the research question;
- literature inclusion/exclusion decisions;
- source verification;
- interpretation;
- final claims and conclusions;
- final citation audit;
- AI-use disclosure.

## Canonical gate sequence

A. **Question Gate** — Steps 1–3  
B. **Source Gate** — Steps 4–6  
C. **Epistemic Gate** — Step 7  
D. **Verification Gate** — Steps 8–12  
E. **Claim Gate** — Steps 13–15  
F. **Integrity Gate** — Steps 16–18

Read `references/aaa_v1_canonical_18steps.md` for exact step wording.

## State-machine behavior

Treat the workflow as a controlled state machine.

A project may move forward only when the current gate’s pass criteria are met. If a required artifact or human decision is missing, stop at that gate, identify what is missing, and propose the minimum next action.

Backward movement is allowed and often required. In particular:
- a changed research question may return the project to Steps 2–4;
- a new evidence need returns to Step 4;
- a failed Atomic Sentence returns to discard/new extraction, not to editing of the failed unit;
- a materially changed Atomic Sentence returns to Step 10 for re-verification;
- reviewer-generated claims return through Step 17 to Steps 4–12.

## Evidence-state model

Use exactly these controlled states unless the user asks for a derivative system:

`UNVERIFIED → TO VERIFY → VERIFIED → TRACEABLE`

Additional disposition states may be used operationally:
- `DISCARD` — failed verification or unusable unit;
- `NEEDS NEW SEARCH` — claim requires evidence not yet in the source library.

See `references/evidence_states.md` for definitions and transitions.

## Minimum project inputs

At least one of these is required to start:
- `research_observation`, or
- `research_question`.

Other fields may be inferred or left pending:
- title;
- framework (PICO / PECO / PICOT / SPIDER / other);
- discipline;
- current step;
- available databases;
- full-text availability;
- existing reference manager/library;
- draft availability;
- citation style;
- language;
- permission to use web or connected sources.

Use `templates/project_state.yaml` when persistent state tracking is useful.

## Standard response contract

For `plan`, `run`, `audit`, and `resume` modes, default to this compact status block before substantive work:

- **AAA v1.0 current position:** Gate + Step
- **Current evidence state:** relevant state(s)
- **What is available:** source/draft/artifact summary
- **Human decision required:** only if needed
- **Next action:** one concrete next step

Do not overuse this block when the user asks for a simple explanation or export.

## Step execution rules

### Steps 1–3: Question Gate
- Preserve the user’s original observation separately from the structured question.
- AI may propose PICO/PECO/PICOT/SPIDER variants, but the researcher confirms the final research question.
- Step 3 produces search concepts and synonyms, not fabricated references.

### Steps 4–6: Source Gate
- Prefer reproducible database search plus citation mapping.
- Record database/platform, date, query, filters, hit count, screening decisions, and retrieval status.
- Human screening determines inclusion/exclusion.
- Build a traceable full-text/reference library.

### Step 7: Epistemic Gate
- AI-assisted reading outputs are `UNVERIFIED`.
- Clearly separate reading notes from citable evidence.
- Do not convert summaries into manuscript claims at this step.

### Steps 8–12: Verification Gate
- Step 8 creates **Candidate Atomic Sentences** and MUST use the canonical Appendix 1 Section 7 Prompt 1 in `references/candidate_as_prompt.md` (or the parameterized rendering in `templates/prompt1_candidate_as.txt`). Its grounding, word-limit, quality, and output constraints must not be weakened.
- Every Step 8 output is `TO VERIFY`; source-grounded extraction does not itself authorize `VERIFIED`.
- Step 9 attaches provenance metadata.
- Step 10 requires human cross-reference verification against the original PDF/full text.
- Step 11 discards failures; do not repair them in place.
- Step 12 applies SPS only after validity is established. If content is materially changed, re-verify it.

### Steps 13–15: Claim Gate
- Step 13 builds the **Verified AS Library**.
- Step 14 is executed as two controlled subphases without changing the canonical 18-step numbering:
  - **Step 14A — Verified-AS synthesis:** MUST use Appendix 1 Section 7 Prompt 2 from `references/verified_as_synthesis_prompt.md`: organize VERIFIED AS units into coherent prose, preserve every citation exactly, and introduce no new claim or reference.
  - **Step 14B — Write and polish:** MAY use a nongrounded writing/polishing model only under `references/write_and_polish_wrapper.md`. It may improve language/rhetoric but may not change evidentiary meaning or introduce a new claim/reference.
- If either Step 14A or 14B requires a new evidence-bearing proposition, mark `NEEDS NEW SEARCH` / `[NEEDS NEW EVIDENCE]` and activate Step 17.
- Step 15 performs paragraph/claim trace-back: manuscript claim → Verified AS → source/page.

### Steps 16–18: Integrity Gate
- Step 16 may simulate peer review, but reviewer suggestions are not evidence.
- Step 17 routes every new claim/evidence need back to Steps 4–12.
- Step 18 requires human final review, citation audit, and AI disclosure.

## Atomic Sentence handling

Use the following default metadata fields:

`sentence | author | year | page_or_locator | functional_role_or_tags | evidence_state`

Recommended optional fields:
- source_id / DOI / PMID;
- direct support excerpt or locator;
- verification date;
- verifier initials;
- SPS;
- notes.

When extracting Candidate AS units, first render and use the canonical Prompt 1 (`references/candidate_as_prompt.md` / `templates/prompt1_candidate_as.txt`). Then:
- target semantic completeness and independent readability;
- keep one independently verifiable claim per unit;
- use the source’s terminology;
- avoid adding interpretation not present in the source;
- keep statistics, denominators, conditions, and comparison groups when essential;
- never fabricate page numbers if the source has no stable pagination.

Read `references/atomic_sentence_sps.md` for detailed rules.

## Drafting behavior

Step 14 uses a protected two-stage sequence:

`Verified AS Library → Step 14A Canonical Prompt 2 → Step 14B constrained Write and polish → Step 15 trace-back`

The order matters. Step 14B must not be used to bypass Prompt 2 or to enlarge the evidence set.

Evidence-constrained drafting means:
- build prose from `VERIFIED` or `TRACEABLE` units only;
- preserve source meaning and citation attribution;
- do not add a novel empirical claim merely to improve flow;
- distinguish evidence, interpretation, hypothesis, and recommendation;
- where a transition requires a substantive new claim, mark `NEEDS NEW SEARCH` and activate Step 17;
- language polishing may improve readability but must not alter evidentiary meaning.

## Audit behavior

For `audit` mode, evaluate at least:
1. Is the research question human-confirmed?
2. Are search and screening records reproducible?
3. Are AI reading notes separated from evidence?
4. Does every controlled claim have a Verified AS or equivalent verified source record?
5. Did verification precede SPS/quality scoring?
6. Were failed units discarded rather than repaired in place?
7. Can every manuscript claim trace back to source and locator?
8. Did reviewer-generated/new claims pass Step 17?
9. Are uncited references and unsupported citations absent?
10. Is AI use disclosed with sufficient tool/role/verification/privacy detail?
11. Did Step 8 use canonical Prompt 1 (or a semantically identical parameterized rendering) and keep all outputs `TO VERIFY` until human verification?
12. Did Step 14A use canonical Prompt 2, preserving citations exactly and introducing no new claim/reference?
13. Did Step 14B remain language/rhetoric polishing only, with any new evidence need routed through Step 17?

Classify findings as:
- `PASS`
- `PARTIAL`
- `BLOCKED`
- `NOT ASSESSABLE`

Do not call an item `PASS` without evidence.

## Resume behavior

When the user provides an existing workspace or artifacts, infer the **highest completed valid step**, not merely the most advanced-looking artifact.

Example: a polished literature review built from AI summaries without human source verification is not Step 15; it is blocked at Step 10 or earlier.

State the inferred current step and the evidence for that inference.

## Disclosure behavior

At Step 18, generate a draft disclosure that the human author must confirm. Prefer the reporting elements in `references/gamer_reporting.md`, including:
- general declaration of AI use;
- tool name/version/developer/settings when known;
- prompting technique/prompts when relevant;
- role of AI in the study/manuscript;
- whether any new model was developed;
- manuscript sections assisted by AI;
- content verification procedure;
- privacy/data governance;
- whether/how AI affected conclusions.

Never claim that AI “verified” the final manuscript on behalf of the authors.

## Export behavior

When generating a flowchart or handout specification, preserve:
- title: `AAA (AI Assisted Academic Writing)` unless the user specifies otherwise;
- six gates and eighteen canonical steps;
- evidence states;
- Step 17 feedback loop to Steps 4–12;
- human decision/verification points;
- the rule `Validity before Quality`;
- the rule `Verification failure = DISCARD`.

If the user requests a visual artifact, follow the appropriate artifact-generation skill/tool instructions for that file type.

## Source basis for this skill

This AAA v1.0 skill operationalizes the user-approved revised 18-step SOP and incorporates the source-verification principles described in:
- Liu SW, Chu SY, Wang HC, Lee MS. *Teaching the Atomic Sentence Method for Source-Verified, AI-Assisted Literature Synthesis to Clinical Health Care Professionals: Single-Cohort Feasibility and Acceptability Study*. JMIR Formative Research. 2026;10:e98343. doi:10.2196/98343.
- Multimedia Appendix 1 of that article: Atomic Sentence method, Source-Verification Workflow, Semantic Purity Score, prompt templates, and cross-reference verification procedure.
- GAMER reporting checklist cited by the article: Luo X, Tham YC, Giuffrè M, et al. *Reporting guideline for the use of Generative Artificial intelligence tools in MEdical Research: the GAMER Statement*. BMJ Evidence-Based Medicine. 2025;30(6):390-400. doi:10.1136/bmjebm-2025-113825.

The source article reports a seven-step AI-assisted research workflow and an Atomic Sentence verification procedure. The **six-gate, eighteen-step AAA v1.0 structure is a derived operational SOP**, not a verbatim structure from the article; keep that distinction explicit when explaining provenance.
