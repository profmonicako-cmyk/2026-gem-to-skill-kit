# Changelog

## 1.1.0 — 2026-08-29

This is a **package/execution-specification revision** of AAA v1.0. The six gates and 18 canonical steps are unchanged.

### Added
- Canonical Appendix 1 Section 7 **Prompt 1** for Step 8 (`references/candidate_as_prompt.md`).
- Parameterized executable Prompt 1 template (`templates/prompt1_candidate_as.txt`).
- Mandatory rule that every Prompt 1 output enters as `TO VERIFY`, not `VERIFIED`.
- Canonical Appendix 1 Section 7 **Prompt 2** for Step 14A (`references/verified_as_synthesis_prompt.md`).
- Executable Prompt 2 template (`templates/prompt2_verified_as_synthesis.txt`).
- Step 14 split into **14A Verified-AS synthesis** and **14B constrained Write and polish**, without changing 18-step numbering.
- Article-aligned Write-and-Polish wrapper prohibiting new claims/references (`references/write_and_polish_wrapper.md`; `templates/write_and_polish_wrapper.txt`).
- Explicit Step 17 trigger when synthesis/polishing requires new evidence.
- Audit checks for Prompt 1, Prompt 2, and Write-and-Polish compliance.

### Clarified
- Prompt 1's source-grounding constraints cannot be weakened.
- Prompt 2 establishes a closed evidence set: preserve every citation exactly; no new claim or reference.
- Nongrounded writing/polishing tools may improve language and rhetoric only; they cannot enlarge the evidence set.
