# Canonical Verified Atomic Sentence Synthesis Prompt (Appendix 1, Section 7, Prompt 2)

**AAA package revision:** 1.1.0  
**Workflow location:** Step 14A — Verified-AS synthesis  
**Precondition:** Manual verification completed; input units are `VERIFIED` (or `TRACEABLE`).

This prompt is the canonical synthesis prompt reproduced from Multimedia Appendix 1, Section 7. It establishes a closed evidence set for drafting.

## Canonical Prompt 2

```text
Organize the following VERIFIED atomic sentences into a coherent paragraph.
Preserve every citation exactly. Do NOT introduce any new claim or reference.
<paste verified atomic sentences here>
```

## Non-negotiable AAA v1.0 constraints

The three substantive constraints below MUST be preserved exactly in meaning:

1. `VERIFIED` Atomic Sentences are the only evidence-bearing input.
2. Preserve every citation exactly.
3. Do not introduce any new claim or reference.

If synthesis appears to require a new empirical/factual claim, statistic, causal statement, mechanism, comparison, or citation, do not add it. Mark the gap `NEEDS NEW SEARCH` and activate Step 17, returning to Steps 4–12.
