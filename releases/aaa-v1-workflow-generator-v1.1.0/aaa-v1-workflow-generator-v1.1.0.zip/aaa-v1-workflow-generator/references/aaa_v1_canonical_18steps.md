# AAA v1.0 Canonical Revised 18-Step SOP

**Package revision: 1.1.0** — The canonical six gates and 18 steps are unchanged. Revision 1.1.0 adds explicit Prompt 1 execution to Step 8 and a two-subphase implementation (Prompt 2 synthesis → constrained Write and polish) inside Step 14.

Do not change the numbering or gate assignment unless the user explicitly requests a derivative version.

## A. Question Gate

### Step 1. Write the original research observation and motivation
Capture the clinical, educational, public-health, methodological, or operational observation before formal restructuring.

**Human role:** own the observation, problem significance, and intended research direction.  
**AI role:** clarify wording and elicit missing contextual elements without replacing the user’s observation.  
**Output:** original observation statement + research motivation.  
**Gate condition:** the observation is sufficiently concrete to structure into a researchable question.

### Step 2. Human confirmation and definition of the research question
Translate the observation into a structured research question using an appropriate framework (e.g., PICO, PECO, PICOT, SPIDER, or another discipline-specific framework).

**Human role:** confirm population/context, exposure/intervention, comparison, outcomes, scope, and feasibility.  
**AI role:** propose candidate structures and point out ambiguities.  
**Output:** human-confirmed structured research question.  
**Gate condition:** the researcher explicitly accepts the question/scope.

### Step 3. AI-assisted generation of search concepts, keywords, and synonyms
Create concept blocks, controlled vocabulary candidates, spelling variants, abbreviations, and related terms.

**Human role:** confirm conceptual relevance and domain appropriateness.  
**AI role:** broaden search vocabulary and structure Boolean-ready concept blocks.  
**Output:** searchable concept matrix.  
**Important:** this step does not create or validate references.

## B. Source Gate

### Step 4. Formal database search + citation mapping
Run reproducible database searches and complementary citation mapping/snowballing.

**Human role:** select databases, approve final queries, and judge search adequacy.  
**AI/tool role:** help optimize syntax, document search strings, and map citation networks.  
**Output:** search log + candidate records.  
**Quality gate:** search is reproducible and aligned with the confirmed question.

### Step 5. Human screening and full-text retrieval
Screen titles/abstracts, apply inclusion/exclusion criteria, and obtain relevant full texts.

**Human role:** final inclusion/exclusion decisions.  
**AI role:** assist prioritization or duplicate detection only when transparently labeled.  
**Output:** screened included set + exclusion reasons + full-text retrieval status.

### Step 6. Build a traceable reference/full-text library
Organize references and full texts with stable identifiers and retrieval provenance.

**Human role:** ensure included sources and full texts are correct.  
**AI/tool role:** metadata normalization and organization support.  
**Output:** reference library + full-text library + source IDs.

## C. Epistemic Gate

### Step 7. AI-assisted reading, with all outputs labeled UNVERIFIED
Use AI to summarize, compare, explain, or locate possible findings, but treat all AI-generated reading notes as provisional.

**Human role:** interpret and decide what may be worth extracting.  
**AI role:** accelerate comprehension.  
**Output:** `UNVERIFIED` reading notes.  
**Gate condition:** reading notes remain clearly separated from verified evidence.

## D. Verification Gate

### Step 8. Generate Candidate Atomic Sentences
Decompose source content into semantically complete, independently readable, source-traceable candidate units containing one principal verifiable claim.

**Canonical execution:** use Appendix 1 Section 7 Prompt 1 as preserved in `candidate_as_prompt.md`. The core topic is parameterized from the human-confirmed question, and the extraction intent is selected as A1/A2/A3/A4. The grounding, word-limit, quality, and output constraints are mandatory.

**Evidence state:** `TO VERIFY` — never `VERIFIED` at generation.  
**Output:** candidate AS table in the canonical form `sentence | Author | Year | Page | #tags`, then enriched with AAA workflow fields as needed.

### Step 9. Attach provenance metadata
Attach at minimum: sentence, author, year, page/locator, and functional role/tags. Stable source identifiers are recommended.

**Output:** source-linked candidate AS records.  
**Important:** provenance metadata improves traceability but is not itself verification.

### Step 10. Human sentence-by-sentence cross-reference verification against the original PDF/full text
Confirm that:
1. the cited source exists and is the intended source; and
2. the source supports the exact claim, statistic, direction, condition, and attribution.

**Human role:** authoritative verifier.  
**AI role:** prepare comparison views or highlight candidate passages, but cannot self-authorize `VERIFIED`.  
**Output:** verification decision for every candidate AS.

### Step 11. Verification failure → DISCARD, not in-place repair
If the source does not support the unit, discard the unit. If a revised claim is desired, create a new candidate unit and re-verify it.

**Output:** retained verified units + discard log.

### Step 12. SPS quality scoring; split/rewrite if needed, then re-verify if meaning changes
Apply the Semantic Purity Score only after validity is established.

**Rule:** `Validity before Quality.`  
**Rule:** any material change to content invalidates the previous verification and returns the unit to Step 10.  
**Output:** high-quality verified units suitable for library inclusion.

## E. Claim Gate

### Step 13. Build the Verified Atomic Sentence Library
Move verified, quality-acceptable units into a controlled evidence library.

**Evidence state:** `VERIFIED`.  
**Output:** Verified AS Library.

### Step 14. Evidence-constrained drafting
Draft paragraphs/sections using only verified evidence for substantive empirical claims. Step 14 has two controlled subphases; these do not add new steps to the 18-step SOP.

#### Step 14A. Verified-AS synthesis — Canonical Prompt 2
Use Appendix 1 Section 7 Prompt 2 as preserved in `verified_as_synthesis_prompt.md`:

> Organize the following VERIFIED atomic sentences into a coherent paragraph. Preserve every citation exactly. Do NOT introduce any new claim or reference.

This creates a closed evidence set. If a new evidence-bearing statement is needed, do not add it; activate Step 17.

#### Step 14B. Write and polish
Writing/polishing tools may improve grammar, syntax, transitions, coherence, redundancy, academic tone, and rhetorical flow only under the AAA Write-and-Polish wrapper. They must preserve every citation exactly and preserve the meaning, statistics, denominators, direction, qualifiers, conditions, and comparisons of verified claims. They may not introduce a new factual claim or reference.

**AI role:** organize verified units (14A) and polish language/rhetoric within the evidence boundary (14B).  
**Human role:** argument structure, explicit interpretation, and responsibility for meaning.  
**Output:** evidence-constrained draft ready for Step 15 trace-back.

### Step 15. Paragraph-by-paragraph / claim-level trace-back
For every substantive manuscript claim, trace:

`manuscript claim → Verified AS → original source + locator`

When trace-back is complete, the claim can be marked `TRACEABLE`.

**Output:** trace-back matrix / claim-evidence matrix.

## F. Integrity Gate

### Step 16. AI-assisted peer-review simulation
Use AI or other tools to simulate reviewer critique, identify logical gaps, missing controls, unclear methods, alternative interpretations, or evidence needs.

**Important:** reviewer suggestions are `UNVERIFIED` and cannot enter the draft as evidence by themselves.

### Step 17. Claim-triggered evidence loop
Any proposed new factual claim, statistic, comparison, mechanism, or evidence need triggers a return to Steps 4–12.

**Canonical loop:**  
`new claim/evidence need → Step 4 search → Step 5 screening → Step 6 source library → Step 7 reading → Steps 8–12 extraction/verification/quality`

Only then may the new evidence enter Step 13 and downstream drafting.

### Step 18. Human final review + citation audit + AI disclosure
Perform final human review for:
- factual accuracy;
- interpretation;
- citation support;
- uncited references;
- references cited for unsupported claims;
- traceability gaps;
- consistency between text, tables, and references;
- AI-use disclosure;
- privacy/data-governance compliance.

**Human role:** final accountability and approval.  
**Output:** submission-ready manuscript/proposal and disclosure record.
