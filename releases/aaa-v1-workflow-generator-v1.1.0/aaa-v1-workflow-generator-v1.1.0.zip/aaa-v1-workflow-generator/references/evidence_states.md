# AAA v1.0 Evidence States

## Controlled states

### UNVERIFIED
Meaning: content has not been cross-referenced against the original source by the human researcher.

Typical examples:
- AI reading summaries;
- AI-generated literature overviews;
- reviewer-simulation suggestions;
- search-engine snippets;
- provisional interpretations;
- extracted statements without source checking.

**May enter controlled manuscript as evidence?** No.

### TO VERIFY
Meaning: a candidate claim/Atomic Sentence has explicit source provenance but has not yet passed human cross-reference verification.

Typical required fields:
- candidate sentence;
- source ID;
- author/year;
- page/locator;
- functional role/tags.

**May enter controlled manuscript as evidence?** No.

### VERIFIED
Meaning: the human researcher has checked the original source and confirmed that the source supports the exact claim/statistic/attribution.

**Authority:** only explicit human verification can authorize this state.

**May enter controlled manuscript as evidence?** Yes.

### TRACEABLE
Meaning: the manuscript claim has been linked through the controlled evidence record to its original source and locator.

Canonical relationship:
`manuscript claim → Verified AS → source + locator`

**May enter final controlled manuscript?** Yes, subject to final integrity audit.

## Operational disposition states

### DISCARD
The unit failed verification or is unusable. It must not be repaired in place while retaining the old verification/citation relationship.

### NEEDS NEW SEARCH
A draft/reviewer-generated claim requires evidence not currently available in the verified library. Activate Step 17.

## Allowed transitions

`UNVERIFIED → TO VERIFY`  
Requires creation of an explicit candidate claim with source provenance.

`TO VERIFY → VERIFIED`  
Requires explicit human cross-reference verification against original source.

`VERIFIED → TRACEABLE`  
Requires claim-level/paragraph-level trace-back in the manuscript.

`TO VERIFY → DISCARD`  
Occurs when verification fails.

`VERIFIED → TO VERIFY`  
Occurs when the sentence is materially rewritten or its meaning changes.

`Any drafting state → NEEDS NEW SEARCH`  
Occurs when a new unsupported claim/evidence need appears.

## Forbidden transitions

- `UNVERIFIED → VERIFIED` based only on AI confidence.
- `TO VERIFY → VERIFIED` without human source check.
- `DISCARD → VERIFIED` by wording repair alone.
- `UNVERIFIED reviewer suggestion → manuscript evidence` without Steps 4–12.
