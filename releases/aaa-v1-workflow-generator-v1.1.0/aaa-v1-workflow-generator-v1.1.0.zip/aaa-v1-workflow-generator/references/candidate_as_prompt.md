# Canonical Candidate Atomic Sentence Extraction Prompt (Appendix 1, Section 7, Prompt 1)

**AAA package revision:** 1.1.0  
**Workflow location:** Step 8 — Generate Candidate Atomic Sentences  
**Evidence state after generation:** `TO VERIFY`

This prompt is the canonical extraction prompt reproduced from Multimedia Appendix 1, Section 7. In AAA v1.0, Step 8 MUST use this prompt or a semantically identical parameterized rendering. The grounding, word-limit, quality, and output constraints MUST NOT be weakened.

## Canonical Prompt 1

```text
[TASK] Precise atomic-sentence extraction from the uploaded source(s) ONLY.
[CORE TOPIC] <your PICO-aligned topic, e.g., "How does AI-based virtual quality-control teaching affect medical technologists' competency?">
[EXTRACTION INTENT] A1 = core findings (results, effect sizes, statistics)
 (A2 = mechanism/theory; A3 = methods; A4 = limitations)
[WORD LIMIT] A1: 15-18 words; A2: 20-30; A3: 25-35; A4: <=25
[QUALITY] semantically complete; independently readable; concise; SPS target >= 8
[GROUNDING] Use ONLY the uploaded sources. Do NOT add any fact not present in
 the sources. If a claim is not in the sources, omit it.
[OUTPUT] SimpleText, one per line: sentence | Author | Year | Page | #tags
[RUN] Extract atomic sentences from the source(s) I have uploaded.
```

## AAA v1.0 execution rules

1. Replace only the `<your PICO-aligned topic ...>` placeholder with the human-confirmed core topic from Steps 1–3.
2. Select/declare the extraction intent (`A1`, `A2`, `A3`, or `A4`) without changing the canonical intent definitions.
3. Use only source-grounded full text supplied/selected in the Source Gate. If the execution environment cannot guarantee source grounding, clearly label the output as provisional and do not imply that Appendix 1 grounding requirements have been met.
4. Every generated unit enters AAA as `TO VERIFY`, never directly as `VERIFIED`.
5. Step 9 must add provenance metadata. Step 10 requires human cross-reference verification against the original PDF/full text.
6. Any unit that fails Step 10 is `DISCARD`; it is not repaired in place.
7. SPS is a quality score and is applied only after validity has been established (Step 12).
