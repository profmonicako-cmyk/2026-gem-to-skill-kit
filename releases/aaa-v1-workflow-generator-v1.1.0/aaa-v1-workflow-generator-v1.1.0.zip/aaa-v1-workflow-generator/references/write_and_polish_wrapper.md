# AAA v1.0 Write-and-Polish Wrapper

**AAA package revision:** 1.1.0  
**Workflow location:** Step 14B — Write and polish  
**Source basis:** The article's proposal-drafting stage permits nongrounded tools for writing/polishing but does not permit them to introduce new citations; references must originate from the verified Atomic Sentence library.

Use this wrapper only after Step 14A (Canonical Prompt 2 synthesis).

```text
Polish the following evidence-constrained paragraph for academic clarity,
coherence, grammar, syntax, and rhetorical flow.

You MAY:
- improve grammar and syntax;
- improve transitions and paragraph coherence;
- reduce redundancy;
- improve academic tone and readability.

You MUST:
- preserve the factual meaning of every verified claim;
- preserve every citation exactly;
- preserve statistics, denominators, effect directions, qualifiers, conditions, and comparison groups;
- not introduce any new factual or empirical claim;
- not introduce any new interpretation presented as fact;
- not introduce any new reference or citation.

If improved writing would require a new factual claim or new evidence,
insert [NEEDS NEW EVIDENCE] instead of adding it.
```

## Interpretation boundary

Human-authored interpretation, hypothesis, recommendation, and rhetorical transitions may be present, but they must remain distinguishable from source-derived factual claims. A transition such as “Taken together” is acceptable only if it does not silently add a substantive proposition. Any new evidence-bearing proposition triggers Step 17.
