# Atomic Sentence and Semantic Purity Score (SPS)

This file summarizes the Atomic Sentence method described in the source article’s Multimedia Appendix 1 and adapts it for AAA v1.0 workflow control.

## Atomic Sentence definition

An Atomic Sentence (AS) is a semantically complete, independently readable, source-traceable knowledge unit designed to be recombined during synthesis.

The source appendix gives a general target of approximately ≤25 words, while also providing intent-specific guidance (e.g., somewhat longer units may be appropriate for methods/mechanisms). Treat concision as a quality target rather than a reason to delete essential conditions or statistics.

## Core criteria

1. **Semantic completeness** — enough context to understand who/what/result/condition without the surrounding paragraph.
2. **Independent readability** — a reader unfamiliar with the paper can understand the unit without resolving pronouns or hidden context.
3. **Recomposability** — the unit can be combined with verified units from other sources without changing its meaning.

## Default metadata

Minimum:
`sentence | author | year | page_or_locator | functional_role_or_tags`

AAA v1.0 adds:
`source_id | evidence_state | verification_result | verifier | verification_date | SPS | notes`

## Candidate AS rule

Before human source verification, every extracted AS is `TO VERIFY`.

Do not use source-grounded generation itself as proof of verification.

## Cross-reference verification

For every candidate unit, the human verifier confirms against the original full text:
1. the source exists and is correctly identified;
2. the source supports the exact claim;
3. statistics/numbers/direction/conditions are accurate;
4. attribution is correct;
5. the page/locator is appropriate when stable pagination exists.

Failure on a material element → `DISCARD`.

## Semantic Purity Score (9 points)

The source appendix describes five dimensions totaling 9 points:

| Dimension | Max |
|---|---:|
| Topic relevance | 2 |
| Semantic completeness | 2 |
| Independent readability | 2 |
| Conciseness | 2 |
| Academic value | 1 |
| **Total** | **9** |

Interpretation in the source appendix:
- 9 = ready to reuse without edits;
- 7–8 = high quality, minor fix;
- <7 = revise or discard.

## AAA v1.0 ordering rule

**Validity first, quality second.**

1. Extract candidate AS.
2. Attach provenance.
3. Human-verify against original source.
4. Discard failures.
5. Score retained units with SPS.
6. If a revision changes factual meaning, numbers, conditions, attribution, or scope, return the revised unit to human source verification.

A high SPS never substitutes for source validity.

## Example state lifecycle

`Candidate AS (TO VERIFY)`  
→ human PDF/full-text check  
→ `VERIFIED` or `DISCARD`  
→ SPS quality check  
→ Verified AS Library  
→ drafting  
→ claim trace-back  
→ `TRACEABLE`

## Source basis

Liu SW, Chu SY, Wang HC, Lee MS. Teaching the Atomic Sentence Method for Source-Verified, AI-Assisted Literature Synthesis to Clinical Health Care Professionals: Single-Cohort Feasibility and Acceptability Study. *JMIR Formative Research*. 2026;10:e98343. doi:10.2196/98343.

Multimedia Appendix 1: Atomic Sentence method, Source-Verification Workflow, SPS rubric, worked examples, and prompt templates.
