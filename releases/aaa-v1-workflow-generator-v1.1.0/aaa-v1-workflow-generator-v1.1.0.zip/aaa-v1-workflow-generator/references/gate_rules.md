# AAA v1.0 Gate Rules

## A. Question Gate — Steps 1–3

**Pass criteria**
- Original observation/motivation is documented.
- Research question is structured and explicitly confirmed by the human researcher.
- Search concept blocks are aligned with the confirmed question.

**Blockers**
- AI-generated question has not been human-confirmed.
- Key population/context/outcome/scope remains ambiguous enough to change the search.

## B. Source Gate — Steps 4–6

**Pass criteria**
- Search strategy is reproducible.
- Screening decisions are human-owned.
- Included records have retrieval status and stable source identity.
- Full texts for evidence extraction are available or clearly marked unavailable.

**Blockers**
- Search is only an AI-generated literature list without database/citation verification.
- Included sources cannot be located.
- Full text is required for claim verification but unavailable.

## C. Epistemic Gate — Step 7

**Pass criteria**
- AI reading output is explicitly labeled `UNVERIFIED`.
- Reading notes are stored separately from verified evidence.

**Blockers**
- AI summaries are being treated as citable facts.
- Source provenance is unclear.

## D. Verification Gate — Steps 8–12

**Pass criteria**
- Candidate AS units have source provenance.
- Human source verification has been completed for retained units.
- Failed units are discarded.
- SPS/quality review occurs only after validity verification.
- Any materially changed unit has been re-verified.

**Blockers**
- AI alone marks a unit verified.
- Page/statistic/support cannot be confirmed.
- Failed units are merely rewritten while keeping old verification.

## E. Claim Gate — Steps 13–15

**Pass criteria**
- Controlled evidence library contains only verified units.
- Empirical manuscript claims are drafted from verified evidence.
- Each substantive claim can trace to a verified unit and source locator.

**Blockers**
- Draft introduces unsupported factual content.
- Citation appears in prose but is absent from the verified library.
- Trace-back fails.

## F. Integrity Gate — Steps 16–18

**Pass criteria**
- Peer-review simulation has not bypassed evidence controls.
- All new evidence needs have completed Step 17 loop.
- Final human citation audit is complete.
- AI-use disclosure is complete and accurate.
- Final conclusions are author-owned and supported by the verified evidence base.

**Blockers**
- Reviewer/AI suggestion introduces a new factual claim without verification.
- Unsupported or orphan citations remain.
- AI-use disclosure omits material AI involvement.
